# AdZuiel Quantum Net Manager 4.0

Android Studio project using Kotlin, Jetpack Compose, OkHttp and WorkManager.

## Version 4.0 features
- HTTP multi-connection downloads (2–8 connections only when the server supports byte ranges).
- Pause, resume, cancel, persistent queue and completed-download history.
- WorkManager background execution with up to three automatic retries for failures.
- Delayed download scheduling (0–10,080 minutes); Android may defer execution due to battery and background policies.
- Public Downloads folder publishing through MediaStore.
- Downloads folder file browser with open action.
- Live device-wide RX/TX graph and current connection type.
- Daily device-wide data-usage estimate with an optional MB limit indicator.
- On-demand download throughput test using Cloudflare's public speed-test download endpoint (downloads up to approximately 5 MB per run).
- Bengali/English interface and Dark/Light theme.
- Android ACTION_SEND and ACTION_VIEW browser handoff remain supported.

## Build
Open this folder in Android Studio. Use JDK 17, install Android SDK Platform 35, sync Gradle, then Build > Build APK(s).

## Important limits and testing
- This app cannot increase ISP/Wi-Fi/mobile-network bandwidth. The speed test measures a single test download to Cloudflare and is not a guarantee of speed to other services.
- The speed test consumes mobile/Wi-Fi data. It runs only when the user taps the button.
- RX/TX and daily data usage are device-wide estimates and include other apps. Android traffic counters may reset or be unavailable on some devices.
- The configured data limit is an on-screen indicator only; Android does not allow this ordinary app to block other apps' network traffic or enforce a system-wide data cap.
- Delayed downloads use WorkManager and may run later than requested because of Android battery/background policies.
- Resume and multi-connection require suitable Content-Length and HTTP Range behavior from the server.
- Android 13+ notification permission is requested for visible background download notifications.
- File browser reads the public Downloads collection using MediaStore.
- Browser integration supports Android Share/Open with intents. It cannot add this app directly to Chrome's internal Download menu.
- The project has not been compiled or device-tested in this environment. Verify Gradle sync/build in Android Studio and test with a server you control before production use.

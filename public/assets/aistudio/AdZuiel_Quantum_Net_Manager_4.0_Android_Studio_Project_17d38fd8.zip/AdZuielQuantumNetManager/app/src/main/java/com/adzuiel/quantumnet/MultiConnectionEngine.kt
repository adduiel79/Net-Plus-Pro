package com.adzuiel.quantumnet

import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

data class EngineDownload(
    val id: String, val url: String, val fileName: String, val filePath: String,
    val totalBytes: Long, val downloadedBytes: Long, val connections: Int,
    val state: String, val error: String = ""
) {
    val percent: Int get() = if (totalBytes > 0) ((downloadedBytes * 100) / totalBytes).toInt().coerceIn(0, 100) else 0
}

object MultiConnectionEngine {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS).readTimeout(45, TimeUnit.SECONDS)
        .callTimeout(0, TimeUnit.MILLISECONDS).retryOnConnectionFailure(true).build()

    private data class Control(@Volatile var paused: Boolean = false, @Volatile var cancelled: Boolean = false)
    private val controls = ConcurrentHashMap<String, Control>()
    private val records = ConcurrentHashMap<String, EngineDownload>()

    fun all(): List<EngineDownload> = records.values.sortedByDescending { it.id }
    fun pause(id: String) { controls[id]?.paused = true; records[id]?.let { records[id] = it.copy(state = "Paused") } }
    fun resume(id: String) { controls[id]?.paused = false; records[id]?.let { records[id] = it.copy(state = "Downloading") } }
    fun cancel(id: String) { controls[id]?.cancelled = true; records[id]?.let { File(it.filePath).delete() }; records[id] = records[id]?.copy(state = "Cancelled") ?: return }

    suspend fun start(url: String, directory: File, requestedName: String, requestedConnections: Int,
                      onUpdate: (EngineDownload) -> Unit): EngineDownload = withContext(Dispatchers.IO) {
        require(url.startsWith("https://", true)) { "Only HTTPS URLs are accepted." }
        directory.mkdirs()
        val safeName = requestedName.replace(Regex("[/\\\\:*?\\\"<>|]"), "_").ifBlank { "download.bin" }
        val id = java.util.UUID.randomUUID().toString()
        val file = File(directory, safeName)
        val control = Control()
        controls[id] = control

        val headRequest = Request.Builder().url(url).head().build()
        val (length, rangeAdvertised) = client.newCall(headRequest).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("Server returned HTTP ${response.code}")
            Pair(response.header("Content-Length")?.toLongOrNull() ?: -1L,
                 response.header("Accept-Ranges")?.contains("bytes", true) == true)
        }
        require(length > 0) { "Server did not provide a known Content-Length." }
        val parts = if (rangeAdvertised && length >= 512 * 1024) requestedConnections.coerceIn(2, 8) else 1
        RandomAccessFile(file, "rw").use { it.setLength(length) }
        val downloaded = AtomicLong(0)
        fun publish(state: String, error: String = ""): EngineDownload {
            val item = EngineDownload(id, url, safeName, file.absolutePath, length, downloaded.get(), parts, state, error)
            records[id] = item
            onUpdate(item)
            return item
        }
        publish("Downloading")

        try {
            coroutineScope {
                val chunkSize = (length + parts - 1) / parts
                val tasks = (0 until parts).map { part ->
                    async(Dispatchers.IO) {
                        val from = part * chunkSize
                        val to = minOf(length - 1, from + chunkSize - 1)
                        var offset = from
                        while (offset <= to) {
                            ensureActive()
                            if (control.cancelled) throw CancellationException("Cancelled")
                            while (control.paused && !control.cancelled) {
                                publish("Paused")
                                delay(150)
                                ensureActive()
                            }
                            if (control.cancelled) throw CancellationException("Cancelled")
                            val requestBuilder = Request.Builder().url(url).get()
                            if (parts > 1) requestBuilder.header("Range", "bytes=$offset-$to")
                            client.newCall(requestBuilder.build()).execute().use { response ->
                                val accepted = if (parts > 1) response.code == 206 else (response.code == 200 || response.code == 206)
                                if (!accepted) throw IllegalStateException("Server refused the download request (HTTP ${response.code}).")
                                val body = response.body ?: throw IllegalStateException("Empty response body")
                                RandomAccessFile(file, "rw").use { output ->
                                    output.seek(offset)
                                    val input = body.byteStream()
                                    val buffer = ByteArray(64 * 1024)
                                    while (true) {
                                        ensureActive()
                                        if (control.cancelled) throw CancellationException("Cancelled")
                                        while (control.paused && !control.cancelled) {
                                            publish("Paused")
                                            delay(150)
                                            ensureActive()
                                        }
                                        val n = input.read(buffer)
                                        if (n < 0) break
                                        output.write(buffer, 0, n)
                                        offset += n
                                        downloaded.addAndGet(n.toLong())
                                        publish("Downloading")
                                    }
                                }
                            }
                        }
                    }
                }
                tasks.awaitAll()
            }
            publish("Complete").copy(downloadedBytes = length)
        } catch (e: CancellationException) {
            if (control.cancelled) publish("Cancelled") else publish("Paused")
        } catch (e: Exception) {
            publish("Failed", e.message ?: "Download failed")
        }
    }
}

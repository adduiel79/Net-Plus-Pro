package com.adzuiel.quantumnet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.TimeUnit
import kotlin.coroutines.coroutineContext

class DownloadWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    private val client = OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS).callTimeout(0, TimeUnit.MILLISECONDS)
        .retryOnConnectionFailure(true).build()

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val id = inputData.getString("task_id") ?: return@withContext Result.failure()
        var task = DownloadStore.get(applicationContext, id) ?: return@withContext Result.failure()
        if (task.status == "Cancelled" || task.status == "Complete") return@withContext Result.success()
        try {
            setForeground(foregroundInfo(task))
            task = task.copy(status = "Downloading", error = "")
            DownloadStore.put(applicationContext, task)
            val file = File(task.tempPath)
            file.parentFile?.mkdirs()
            if (!file.exists()) RandomAccessFile(file, "rw").use { it.setLength(task.totalBytes) }

            coroutineScope {
                task.offsets.indices.map { part ->
                    async(Dispatchers.IO) {
                        val chunk = (task.totalBytes + task.connections - 1) / task.connections
                        val start = part * chunk
                        val end = minOf(task.totalBytes - 1, start + chunk - 1)
                        var offset = start + task.offsets[part]
                        while (offset <= end) {
                            coroutineContext.ensureActive()
                            var latest = DownloadStore.get(applicationContext, id) ?: return@async
                            while (latest.status == "Paused") {
                                delay(400)
                                latest = DownloadStore.get(applicationContext, id) ?: return@async
                            }
                            if (latest.status == "Cancelled") return@async
                            val builder = Request.Builder().url(task.url).get()
                            if (task.connections > 1 || offset > start) builder.header("Range", "bytes=$offset-$end")
                            client.newCall(builder.build()).execute().use { response ->
                                if (task.connections > 1 && response.code != 206)
                                    throw IllegalStateException("HTTP ${response.code}: server rejected multi-connection range")
                                if (task.connections == 1 && offset > start && response.code == 200) {
                                    // Server ignored Range: restart this single-stream file safely.
                                    offset = start
                                    updateOffset(id, part, 0L, "Downloading")
                                    RandomAccessFile(file, "rw").use { it.setLength(task.totalBytes) }
                                } else if (response.code != 200 && response.code != 206) {
                                    throw IllegalStateException("HTTP ${response.code}: server rejected download")
                                }
                                val body = response.body ?: throw IllegalStateException("Empty server response")
                                RandomAccessFile(file, "rw").use { output ->
                                    output.seek(offset)
                                    val input = body.byteStream()
                                    val buffer = ByteArray(64 * 1024)
                                    var sinceSave = 0
                                    while (true) {
                                        coroutineContext.ensureActive()
                                        latest = DownloadStore.get(applicationContext, id) ?: return@use
                                        while (latest.status == "Paused") {
                                            delay(400)
                                            latest = DownloadStore.get(applicationContext, id) ?: return@use
                                        }
                                        if (latest.status == "Cancelled") return@use
                                        val n = input.read(buffer)
                                        if (n < 0) break
                                        output.write(buffer, 0, n)
                                        offset += n
                                        sinceSave += n
                                        if (sinceSave >= 256 * 1024) {
                                            updateOffset(id, part, offset - start, "Downloading")
                                            sinceSave = 0
                                        }
                                    }
                                    updateOffset(id, part, offset - start, "Downloading")
                                }
                            }
                        }
                    }
                }.awaitAll()
            }
            val finalTask = DownloadStore.get(applicationContext, id) ?: return@withContext Result.success()
            if (finalTask.status == "Cancelled") return@withContext Result.success()
            if (finalTask.downloadedBytes >= finalTask.totalBytes) {
                val uri = PublicDownloads.publish(applicationContext, File(finalTask.tempPath), finalTask.fileName)
                File(finalTask.tempPath).delete()
                DownloadStore.put(applicationContext, finalTask.copy(status = "Complete", error = "Saved to Downloads: $uri"))
                applicationContext.getSystemService(NotificationManager::class.java).notify(id.hashCode(), notification(finalTask, "Download complete", true))
                Result.success()
            } else {
                Result.retry()
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            val latest = DownloadStore.get(applicationContext, id)
            if (latest != null) DownloadStore.put(applicationContext, latest.copy(status = "Failed", error = e.message ?: "Download failed"))
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }

    private fun updateOffset(id: String, part: Int, offset: Long, status: String) {
        synchronized(DownloadStore) {
            val t = DownloadStore.get(applicationContext, id) ?: return
            val updated = t.offsets.toMutableList()
            updated[part] = offset.coerceAtMost(t.totalBytes)
            DownloadStore.put(applicationContext, t.copy(offsets = updated, status = status))
        }
    }

    private fun foregroundInfo(task: DownloadTask): ForegroundInfo {
        createChannel()
        val notification = notification(task, "Downloading ${task.fileName}", false)
        return if (Build.VERSION.SDK_INT >= 29)
            ForegroundInfo(task.id.hashCode(), notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo(task.id.hashCode(), notification)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(NotificationChannel("quantum_downloads", "Quantum downloads", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun notification(task: DownloadTask, title: String, done: Boolean): Notification =
        NotificationCompat.Builder(applicationContext, "quantum_downloads")
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(title).setContentText(if (done) task.fileName else "${task.percent}% · ${task.fileName}")
            .setOngoing(!done).setOnlyAlertOnce(true).build()
}

package com.adzuiel.quantumnet

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileInputStream

object PublicDownloads {
    fun publish(context: Context, source: File, fileName: String): String {
        val resolver = context.contentResolver
        val collection = if (Build.VERSION.SDK_INT >= 29)
            MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        else MediaStore.Files.getContentUri("external")
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/AdZuiel Quantum")
        }
        val uri = resolver.insert(collection, values) ?: throw IllegalStateException("Could not create file in public Downloads")
        try {
            resolver.openOutputStream(uri, "w")?.use { output -> FileInputStream(source).use { it.copyTo(output) } }
                ?: throw IllegalStateException("Could not open public Downloads output")
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
        return uri.toString()
    }
}

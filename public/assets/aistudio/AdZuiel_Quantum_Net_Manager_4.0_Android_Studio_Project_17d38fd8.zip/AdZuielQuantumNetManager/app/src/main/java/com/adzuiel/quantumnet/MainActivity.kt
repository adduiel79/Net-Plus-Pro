package com.adzuiel.quantumnet

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.TrafficStats
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.work.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URL
import java.util.Locale
import java.util.concurrent.TimeUnit

private val Bg = Color(0xFF070A12)
private val Panel = Color(0xFF111827)
private val Line = Color(0xFF273247)
private val Lime = Color(0xFFC5F542)
private val Cyan = Color(0xFF38D6D8)
private val Purple = Color(0xFFB58AFF)
private val Muted = Color(0xFFAAB4C8)

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { QuantumApp(this, extractIncomingUrl(intent)) }
    }
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }
    private fun extractIncomingUrl(source: Intent?): String {
        if (source == null) return ""
        if (source.action == Intent.ACTION_VIEW)
            return source.dataString?.takeIf { it.startsWith("http://") || it.startsWith("https://") }.orEmpty()
        if (source.action == Intent.ACTION_SEND) {
            val text = source.getStringExtra(Intent.EXTRA_TEXT)?.trim().orEmpty()
            return Regex("""https?://\S+""", RegexOption.IGNORE_CASE).find(text)?.value?.trimEnd('.', ',', ')', ']', '}', '>').orEmpty()
        }
        return ""
    }
}

private data class DownloadedFile(val name: String, val size: Long, val uri: android.net.Uri)

@Composable
private fun QuantumApp(context: Context, sharedUrl: String = "") {
    val prefs = remember { context.getSharedPreferences("quantum_v4_settings", Context.MODE_PRIVATE) }
    var bengali by remember { mutableStateOf(prefs.getBoolean("bn", true)) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
    var tab by remember { mutableIntStateOf(0) }
    var url by remember { mutableStateOf(sharedUrl) }
    var name by remember { mutableStateOf("") }
    var connections by remember { mutableIntStateOf(4) }
    var scheduleMinutes by remember { mutableStateOf("0") }
    var dataLimitMb by remember { mutableStateOf(prefs.getInt("limit_mb", 0).toString()) }
    var items by remember { mutableStateOf(DownloadStore.all(context)) }
    var files by remember { mutableStateOf(emptyList<DownloadedFile>()) }
    var rx by remember { mutableLongStateOf(0L) }
    var tx by remember { mutableLongStateOf(0L) }
    var network by remember { mutableStateOf("Checking…") }
    var online by remember { mutableStateOf(false) }
    var oldRx by remember { mutableLongStateOf(TrafficStats.getTotalRxBytes()) }
    var oldTx by remember { mutableLongStateOf(TrafficStats.getTotalTxBytes()) }
    var rxHistory by remember { mutableStateOf(listOf(0f)) }
    var txHistory by remember { mutableStateOf(listOf(0f)) }
    var info by remember { mutableStateOf("") }
    var speedTest by remember { mutableStateOf("") }
    var testing by remember { mutableStateOf(false) }
    var dailyBytes by remember { mutableLongStateOf(0L) }

    LaunchedEffect(Unit) {
        val day = java.text.SimpleDateFormat("yyyyMMdd", Locale.US).format(java.util.Date())
        val savedDay = prefs.getString("usage_day", "")
        if (savedDay != day) {
            prefs.edit().putString("usage_day", day).putLong("day_rx_start", TrafficStats.getTotalRxBytes().coerceAtLeast(0)).putLong("day_tx_start", TrafficStats.getTotalTxBytes().coerceAtLeast(0)).apply()
        }
        while (true) {
            val r = TrafficStats.getTotalRxBytes(); val t = TrafficStats.getTotalTxBytes()
            rx = if (oldRx >= 0 && r >= oldRx) (r-oldRx)*8/1000 else 0
            tx = if (oldTx >= 0 && t >= oldTx) (t-oldTx)*8/1000 else 0
            oldRx = r; oldTx = t
            rxHistory = (rxHistory + rx.toFloat()).takeLast(30)
            txHistory = (txHistory + tx.toFloat()).takeLast(30)
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.activeNetwork?.let { cm.getNetworkCapabilities(it) }
            online = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
            network = when {
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "Wi-Fi"
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "Mobile data"
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "Ethernet"
                online -> "Connected"; else -> "Offline"
            }
            val startRx = prefs.getLong("day_rx_start", 0L)
            val startTx = prefs.getLong("day_tx_start", 0L)
            dailyBytes = (r - startRx).coerceAtLeast(0) + (t - startTx).coerceAtLeast(0)
            items = DownloadStore.all(context)
            if (tab == 3) files = queryDownloadedFiles(context)
            delay(1000)
        }
    }

    val isDark = dark
    MaterialTheme(colorScheme = if (isDark) darkColorScheme(primary = Lime, secondary = Cyan, background = Bg, surface = Panel)
        else lightColorScheme(primary = Color(0xFF426B00), secondary = Color(0xFF007C80))) {
        val pageBg = if (isDark) Bg else Color(0xFFF2F5F8)
        val cardBg = if (isDark) Panel else Color.White
        val mainText = if (isDark) Color.White else Color(0xFF152033)
        val mutedText = if (isDark) Muted else Color(0xFF596579)
        Scaffold(containerColor = pageBg, bottomBar = {
            NavigationBar(containerColor = cardBg) {
                NavigationBarItem(tab == 0, { tab = 0 }, icon = { Icon(Icons.Default.Speed, null) }, label = { Text(if (bengali) "নেটওয়ার্ক" else "Network") })
                NavigationBarItem(tab == 1, { tab = 1 }, icon = { Icon(Icons.Default.Download, null) }, label = { Text(if (bengali) "ডাউনলোড" else "Downloads") })
                NavigationBarItem(tab == 2, { tab = 2 }, icon = { Icon(Icons.Default.Folder, null) }, label = { Text(if (bengali) "ফাইল" else "Files") })
                NavigationBarItem(tab == 3, { tab = 3 }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text(if (bengali) "সেটিংস" else "Settings") })
            }
        }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("ADZUIEL", color = if (isDark) Lime else Color(0xFF426B00), fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                        Text("Quantum Net Manager 4.0", color = mainText, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    TextButton(onClick = { bengali = !bengali; prefs.edit().putBoolean("bn", bengali).apply() }) { Text(if (bengali) "EN" else "বাংলা") }
                }
                when (tab) {
                    0 -> NetworkScreen(bengali, network, online, rx, tx, rxHistory, txHistory, dailyBytes, dataLimitMb, { dataLimitMb = it; prefs.edit().putInt("limit_mb", it.toIntOrNull() ?: 0).apply() }, speedTest, testing, {
                        if (!online) { speedTest = if (bengali) "ইন্টারনেট সংযোগ নেই" else "No internet connection"; return@NetworkScreen }
                        testing = true; speedTest = if (bengali) "পরীক্ষা চলছে…" else "Testing…"
                        kotlinx.coroutines.MainScope().launch {
                            speedTest = runSpeedTest()
                            testing = false
                        }
                    }, cardBg, mainText, mutedText)
                    1 -> DownloadScreen(context, bengali, url, { url = it }, name, { name = it }, connections,
                        { connections = it }, scheduleMinutes, { scheduleMinutes = it }, items, { info = it }, cardBg, mainText, mutedText)
                    2 -> FileScreen(context, bengali, files, cardBg, mainText, mutedText)
                    else -> SettingsScreen(bengali, dark, { dark = it; prefs.edit().putBoolean("dark", it).apply() }, cardBg, mainText, mutedText)
                }
                if (info.isNotBlank()) Text(info, color = if (isDark) Lime else Color(0xFF426B00), fontSize = 11.sp, modifier = Modifier.padding(vertical = 5.dp))
            }
        }
    }
}

@Composable
private fun NetworkScreen(bn: Boolean, network: String, online: Boolean, rx: Long, tx: Long,
    rxHistory: List<Float>, txHistory: List<Float>, dailyBytes: Long, limitText: String, onLimit: (String) -> Unit,
    testResult: String, testing: Boolean, onTest: () -> Unit, card: Color, fg: Color, muted: Color) {
    val limit = limitText.toLongOrNull()?.coerceAtLeast(0)?.times(1024L*1024L) ?: 0L
    Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Public, null, tint = Cyan); Spacer(Modifier.width(8.dp))
                    Text(if (bn) "লাইভ নেটওয়ার্ক স্ট্যাটাস" else "LIVE NETWORK STATUS", color = fg, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f)); Text(if (online) "ONLINE" else "OFFLINE", color = if (online) Color(0xFF66B94A) else Color.Red, fontSize = 10.sp)
                }
                Spacer(Modifier.height(12.dp)); Text(network, color = Lime, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                Text(if (bn) "বর্তমান সংযোগ" else "Active connection", color = muted)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SpeedCard(if (bn) "ডাউনলোড" else "DOWNLOAD", rx, Cyan, Modifier.weight(1f), card, fg, muted)
            SpeedCard(if (bn) "আপলোড" else "UPLOAD", tx, Purple, Modifier.weight(1f), card, fg, muted)
        }
        Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(15.dp)) {
                Text(if (bn) "লাইভ স্পিড গ্রাফ · Kbps" else "LIVE SPEED GRAPH · Kbps", color = fg, fontWeight = FontWeight.Bold)
                SpeedGraph(rxHistory, txHistory, Modifier.fillMaxWidth().height(110.dp))
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(if (bn) "আজকের ডেটা ব্যবহার" else "TODAY'S DATA USAGE", color = fg, fontWeight = FontWeight.Bold)
                Text(fmt(dailyBytes), color = Cyan, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(limitText, onLimit, modifier = Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text(if (bn) "ডেটা সীমা (MB, 0 = বন্ধ)" else "Data limit (MB, 0 = off)") })
                if (limit > 0) {
                    LinearProgressIndicator({ (dailyBytes.toFloat()/limit).coerceIn(0f,1f) }, modifier = Modifier.fillMaxWidth())
                    Text(if (dailyBytes >= limit) (if (bn) "সীমা অতিক্রম হয়েছে" else "Limit exceeded") else (if (bn) "ডেটা সীমার মধ্যে" else "Within data limit"), color = if (dailyBytes >= limit) Color.Red else muted)
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (bn) "ইন্টারনেট স্পিড টেস্ট" else "INTERNET SPEED TEST", color = fg, fontWeight = FontWeight.Bold)
                Button(onClick = onTest, enabled = !testing && online) { Icon(Icons.Default.Speed, null); Spacer(Modifier.width(7.dp)); Text(if (testing) (if (bn) "পরীক্ষা চলছে" else "Testing") else (if (bn) "টেস্ট শুরু করুন" else "Run speed test")) }
                if (testResult.isNotBlank()) Text(testResult, color = muted, fontSize = 12.sp)
            }
        }
        Text(if (bn) "ট্রাফিক ও ডেটা ব্যবহার ডিভাইস-ব্যাপী; অন্য অ্যাপের ব্যবহারও অন্তর্ভুক্ত। স্পিড টেস্টে ডেটা খরচ হয়।" else "Traffic and data usage are device-wide and include other apps. Speed testing consumes data.", color = muted, fontSize = 11.sp)
    }
}

@Composable
private fun SpeedGraph(download: List<Float>, upload: List<Float>, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val maxValue = (download + upload).maxOrNull()?.coerceAtLeast(1f) ?: 1f
        repeat(4) { i -> val y = size.height * i / 3f; drawLine(Line, Offset(0f,y), Offset(size.width,y), 1.dp.toPx()) }
        fun series(values: List<Float>, color: Color) {
            if (values.size < 2) return
            val step = size.width/(values.size-1)
            for (i in 0 until values.lastIndex) drawLine(color,
                Offset(i*step, size.height-(values[i]/maxValue)*size.height),
                Offset((i+1)*step, size.height-(values[i+1]/maxValue)*size.height), 3.dp.toPx())
        }
        series(download, Cyan); series(upload, Purple)
    }
}
@Composable
private fun SpeedCard(title: String, value: Long, tint: Color, modifier: Modifier, card: Color, fg: Color, muted: Color) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(value.toString(), color = tint, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
            Text("Kbps", color = muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun DownloadScreen(context: Context, bn: Boolean, url: String, onUrl: (String) -> Unit, name: String, onName: (String) -> Unit,
    connections: Int, onConnections: (Int) -> Unit, schedule: String, onSchedule: (String) -> Unit,
    items: List<DownloadTask>, onInfo: (String) -> Unit, card: Color, fg: Color, muted: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxSize()) {
        Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(if (bn) "স্মার্ট ডাউনলোড" else "SMART DOWNLOAD", color = Lime, fontWeight = FontWeight.Bold)
                OutlinedTextField(url, onUrl, modifier = Modifier.fillMaxWidth(), label = { Text(if (bn) "HTTPS ডাউনলোড লিংক" else "HTTPS download URL") }, singleLine = true)
                OutlinedTextField(name, onName, modifier = Modifier.fillMaxWidth(), label = { Text(if (bn) "ফাইলের নাম (ঐচ্ছিক)" else "File name (optional)") }, singleLine = true)
                Text(if (bn) "সমান্তরাল সংযোগ: $connections" else "Parallel connections: $connections", color = muted)
                Slider(connections.toFloat(), { onConnections(it.toInt().coerceIn(2,8)) }, valueRange = 2f..8f, steps = 5)
                OutlinedTextField(schedule, onSchedule, modifier = Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text(if (bn) "কত মিনিট পরে শুরু (0 = এখনই)" else "Start after minutes (0 = now)") })
                Button(onClick = {
                    val link = url.trim()
                    if (!link.startsWith("https://", true)) { onInfo(if (bn) "বৈধ HTTPS লিংক দিন।" else "Enter a valid HTTPS URL."); return@Button }
                    val delay = schedule.toLongOrNull()
                    if (delay == null || delay !in 0..10080) { onInfo(if (bn) "০–১০০৮০ মিনিট দিন।" else "Enter 0–10080 minutes."); return@Button }
                    val fileName = name.trim().ifBlank { runCatching { URL(link).path.substringAfterLast('/').ifBlank { "download.bin" } }.getOrDefault("download.bin") }
                    onUrl(""); onName(""); onSchedule("0")
                    DownloadManagerV3.enqueue(context, link, fileName, connections, delay) { task ->
                        onInfo(if (task.status == "Failed") task.error else if (delay > 0) (if (bn) "ডাউনলোড নির্ধারিত হয়েছে" else "Download scheduled") else (if (bn) "ডাউনলোড কিউতে যোগ হয়েছে" else "Added to queue"))
                    }
                }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Bg)) {
                    Icon(Icons.Default.Download, null); Spacer(Modifier.width(6.dp)); Text(if (bn) "ডাউনলোড যোগ করুন" else "ADD DOWNLOAD")
                }
                Text(if (bn) "সময়সূচি Android/WorkManager-এর ব্যাটারি নীতির কারণে কিছুটা দেরি হতে পারে।" else "Android battery policy may delay scheduled work.", color = muted, fontSize = 10.sp)
            }
        }
        Text(if (bn) "ডাউনলোড ইতিহাস ও কিউ" else "DOWNLOAD HISTORY & QUEUE", color = fg, fontWeight = FontWeight.Bold)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            items(items, key = { it.id }) { item ->
                Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(item.fileName, color = fg, fontWeight = FontWeight.SemiBold, maxLines = 2)
                        LinearProgressIndicator({ item.percent/100f }, modifier = Modifier.fillMaxWidth(), color = Lime)
                        Text("${item.percent}% · ${item.status} · ${item.connections} connections", color = Cyan, fontSize = 10.sp)
                        Text("${fmt(item.downloadedBytes)} / ${fmt(item.totalBytes)}", color = muted, fontSize = 10.sp)
                        if (item.error.isNotBlank()) Text(item.error, color = Color(0xFFFF8A8A), fontSize = 10.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            if (item.status == "Downloading" || item.status == "Queued") OutlinedButton(onClick = { DownloadManagerV3.pause(context,item.id) }) { Text(if (bn) "পজ" else "Pause") }
                            if (item.status == "Paused" || item.status == "Failed") OutlinedButton(onClick = { DownloadManagerV3.resume(context,item.id) }) { Text(if (bn) "চালু" else "Resume") }
                            if (item.status != "Complete" && item.status != "Cancelled") OutlinedButton(onClick = { DownloadManagerV3.cancel(context,item.id) }) { Text(if (bn) "বাতিল" else "Cancel") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FileScreen(context: Context, bn: Boolean, files: List<DownloadedFile>, card: Color, fg: Color, muted: Color) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (bn) "ডাউনলোড ফোল্ডারের ফাইল" else "FILES IN DOWNLOADS", color = fg, fontWeight = FontWeight.Bold)
        Text(if (bn) "Downloads ফোল্ডারে থাকা ফাইল দেখানো হচ্ছে।" else "Files visible in the public Downloads folder.", color = muted, fontSize = 11.sp)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            items(files, key = { it.uri.toString() }) { file ->
                Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(16.dp),
                    onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(file.uri, "*/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } }) {
                    Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.InsertDriveFile, null, tint = Cyan)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) { Text(file.name, color = fg, maxLines = 2); Text(fmt(file.size), color = muted, fontSize = 10.sp) }
                        Icon(Icons.Default.OpenInNew, null, tint = muted)
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(bn: Boolean, dark: Boolean, onDark: (Boolean) -> Unit, card: Color, fg: Color, muted: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("AdZuiel Quantum Net Manager 4.0", color = Lime, fontWeight = FontWeight.Bold)
                Text(if (bn) "Smart Network & Download Edition" else "Smart Network & Download Edition", color = fg)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (bn) "ডার্ক মোড" else "Dark mode", color = fg, modifier = Modifier.weight(1f))
                    Switch(dark, onDark)
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(if (bn) "সংস্করণ ৪.০ ফিচার" else "VERSION 4.0 FEATURES", color = Cyan, fontWeight = FontWeight.Bold)
                Text(if (bn) "• নির্ধারিত সময়ে ডাউনলোড\n• স্পিড টেস্ট\n• লাইভ নেটওয়ার্ক ও দৈনিক ডেটা ব্যবহার\n• Downloads ফাইল ব্রাউজার\n• ডাউনলোড ইতিহাস ও পুনরায় চেষ্টা\n• বাংলা/ইংরেজি\n• ডার্ক/লাইট মোড" else "• Scheduled downloads\n• Internet speed test\n• Live network and daily data usage\n• Downloads file browser\n• Download history and retry\n• Bengali/English\n• Dark/Light mode", color = fg)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = card), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(17.dp)) {
                Text(if (bn) "গুরুত্বপূর্ণ সীমাবদ্ধতা" else "IMPORTANT LIMITS", color = Cyan, fontWeight = FontWeight.Bold)
                Text(if (bn) "অ্যাপ ISP-র স্পিড বাড়ায় না। স্পিড টেস্টে Cloudflare-এর টেস্ট সার্ভার থেকে ডেটা ডাউনলোড হয়। ডেটা কাউন্টার ডিভাইস-ব্যাপী। Android WorkManager নির্ধারিত কাজ দেরিতে চালাতে পারে। Multi-connection ও Resume সার্ভারের HTTP Range সমর্থনের ওপর নির্ভরশীল।" else "The app cannot increase ISP speed. Speed testing downloads test data from Cloudflare. Usage counters are device-wide. Android WorkManager may delay scheduled jobs. Multi-connection and resume depend on HTTP Range support.", color = muted, fontSize = 12.sp)
            }
        }
    }
}

private suspend fun runSpeedTest(): String = withContext(Dispatchers.IO) {
    val client = OkHttpClient.Builder().callTimeout(45, TimeUnit.SECONDS).build()
    val url = "https://speed.cloudflare.com/__down?bytes=5000000"
    try {
        val start = System.nanoTime()
        val request = Request.Builder().url(url).header("Cache-Control", "no-cache").build()
        val bytes = client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("HTTP ${response.code}")
            val body = response.body ?: throw IllegalStateException("Empty response")
            body.byteStream().use { input ->
                val buffer = ByteArray(32 * 1024); var total = 0L
                while (true) { val n = input.read(buffer); if (n < 0) break; total += n }
                total
            }
        }
        val seconds = ((System.nanoTime()-start)/1_000_000_000.0).coerceAtLeast(0.001)
        val mbps = bytes * 8.0 / seconds / 1_000_000.0
        "Download: ${String.format(Locale.US, "%.2f", mbps)} Mbps · ${fmt(bytes)} tested"
    } catch (e: Exception) { "Speed test failed: ${e.message ?: "network error"}" }
}

private fun queryDownloadedFiles(context: Context): List<DownloadedFile> {
    if (Build.VERSION.SDK_INT < 29) return emptyList()
    val result = mutableListOf<DownloadedFile>()
    val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL)
    val projection = arrayOf(MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns._ID)
    runCatching {
        context.contentResolver.query(collection, projection, null, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { cursor ->
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                result.add(DownloadedFile(cursor.getString(nameCol) ?: "file", cursor.getLong(sizeCol),
                    android.content.ContentUris.withAppendedId(collection, id)))
            }
        }
    }
    return result
}

private fun fmt(v: Long): String = when {
    v < 1024 -> "$v B"
    v < 1024*1024 -> String.format(Locale.US, "%.1f KB", v/1024.0)
    v < 1024L*1024*1024 -> String.format(Locale.US, "%.1f MB", v/(1024.0*1024))
    else -> String.format(Locale.US, "%.2f GB", v/(1024.0*1024*1024))
}

package com.adzuiel.quantumnet

import android.content.Context
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.io.File
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object DownloadManagerV3 {
    private val client = OkHttpClient.Builder().callTimeout(30, TimeUnit.SECONDS).build()
    fun enqueue(context: Context, url: String, name: String, connections: Int, delayMinutes: Long = 0, onCreated: (DownloadTask) -> Unit) {
        Thread {
            try {
                val head = Request.Builder().url(url).head().build()
                val (length, ranges) = client.newCall(head).execute().use { response ->
                    if (!response.isSuccessful) throw IllegalStateException("HTTP ${response.code}")
                    Pair(response.header("Content-Length")?.toLongOrNull() ?: -1L,
                        response.header("Accept-Ranges")?.contains("bytes", true) == true)
                }
                require(length > 0) { "Server must provide Content-Length for resumable downloads." }
                val task = DownloadStore.create(context, url, name, connections, length, ranges)
                onCreated(task)
                enqueueExisting(context, task.id, delayMinutes)
            } catch (e: Exception) {
                onCreated(DownloadTask("error-${System.currentTimeMillis()}", url, name, 0, 1, listOf(0), "", "Failed", e.message ?: "Could not start"))
            }
        }.start()
    }

    fun enqueueExisting(context: Context, id: String, delayMinutes: Long = 0) {
        val request = OneTimeWorkRequestBuilder<DownloadWorker>()
            .setInputData(Data.Builder().putString("task_id", id).build())
            .setInitialDelay(delayMinutes.coerceAtLeast(0), TimeUnit.MINUTES)
            .addTag("quantum_download_$id").build()
        WorkManager.getInstance(context).enqueueUniqueWork("quantum_download_$id", ExistingWorkPolicy.REPLACE, request)
    }

    fun pause(context: Context, id: String) {
        DownloadStore.get(context, id)?.let { DownloadStore.put(context, it.copy(status = "Paused")) }
    }
    fun resume(context: Context, id: String) {
        DownloadStore.get(context, id)?.let {
            DownloadStore.put(context, it.copy(status = "Downloading"))
            enqueueExisting(context, id)
        }
    }
    fun cancel(context: Context, id: String) {
        DownloadStore.get(context, id)?.let {
            DownloadStore.put(context, it.copy(status = "Cancelled"))
            WorkManager.getInstance(context).cancelUniqueWork("quantum_download_$id")
            File(it.tempPath).delete()
        }
    }
}

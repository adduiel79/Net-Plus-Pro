package com.adzuiel.quantumnet

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

data class DownloadTask(
    val id: String,
    val url: String,
    val fileName: String,
    val totalBytes: Long,
    val connections: Int,
    val offsets: List<Long>,
    val tempPath: String,
    val status: String = "Queued",
    val error: String = ""
) {
    val downloadedBytes: Long get() = offsets.sum()
    val percent: Int get() = if (totalBytes > 0) (downloadedBytes * 100 / totalBytes).toInt().coerceIn(0, 100) else 0
}

object DownloadStore {
    private const val PREFS = "quantum_downloads_v3"
    private const val KEY = "tasks"
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized fun all(context: Context): List<DownloadTask> {
        val array = runCatching { JSONArray(prefs(context).getString(KEY, "[]")) }.getOrElse { JSONArray() }
        return (0 until array.length()).mapNotNull { i -> runCatching { decode(array.getJSONObject(i)) }.getOrNull() }
            .sortedByDescending { it.id }
    }

    @Synchronized fun get(context: Context, id: String): DownloadTask? = all(context).firstOrNull { it.id == id }

    @Synchronized fun put(context: Context, task: DownloadTask) {
        val map = all(context).associateBy { it.id }.toMutableMap()
        map[task.id] = task
        save(context, map.values.toList())
    }

    @Synchronized fun remove(context: Context, id: String) {
        save(context, all(context).filterNot { it.id == id })
    }

    private fun save(context: Context, tasks: List<DownloadTask>) {
        val array = JSONArray()
        tasks.forEach { task ->
            val offsets = JSONArray()
            task.offsets.forEach(offsets::put)
            array.put(JSONObject().put("id", task.id).put("url", task.url).put("name", task.fileName)
                .put("total", task.totalBytes).put("connections", task.connections).put("offsets", offsets)
                .put("temp", task.tempPath).put("status", task.status).put("error", task.error))
        }
        prefs(context).edit().putString(KEY, array.toString()).commit()
    }

    private fun decode(o: JSONObject): DownloadTask {
        val offsets = o.getJSONArray("offsets")
        return DownloadTask(o.getString("id"), o.getString("url"), o.getString("name"),
            o.getLong("total"), o.getInt("connections"),
            (0 until offsets.length()).map { offsets.getLong(it) },
            o.getString("temp"), o.optString("status", "Queued"), o.optString("error", ""))
    }

    fun create(context: Context, url: String, name: String, connections: Int, total: Long, ranges: Boolean): DownloadTask {
        val count = if (ranges && total >= 512 * 1024) connections.coerceIn(2, 8) else 1
        val offsets = List(count) { 0L }
        val temp = File(context.filesDir, "quantum_${UUID.randomUUID()}.part")
        temp.parentFile?.mkdirs()
        java.io.RandomAccessFile(temp, "rw").use { it.setLength(total) }
        return DownloadTask(UUID.randomUUID().toString(), url, name, total, count, offsets, temp.absolutePath)
            .also { put(context, it) }
    }
}
